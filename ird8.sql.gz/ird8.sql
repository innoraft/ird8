PHP Fatal error:  Call to undefined function conf_path() in /root/.composer/vendor/drush/drush/lib/Drush/Boot/DrupalBoot.php on line 388
Drush command terminated abnormally due to an unrecoverable error.                                                                                     [error]
Error: Call to undefined function conf_path() in /root/.composer/vendor/drush/drush/lib/Drush/Boot/DrupalBoot.php, line 388
